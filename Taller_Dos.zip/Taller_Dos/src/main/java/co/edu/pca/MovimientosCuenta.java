package co.edu.pca;

interface MovimientosCuenta {
    void depositar(double monto);
    void retirar(double monto);
}
